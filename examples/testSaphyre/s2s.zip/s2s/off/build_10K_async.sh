cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_10K.off";
time ./escalunya_app -f armadillo_10K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_10K &> build_report/armadillo_10K.txt &
echo "...dragon_10K.off";
time ./escalunya_app -f dragon_10K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_10K &> build_report/dragon_10K.txt &
echo "...happy_10K.off";
time ./escalunya_app -f happy_10K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_10K &> build_report/happy_10K.txt &
echo "...horse_10K.off";
time ./escalunya_app -f horse_10K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/horse_10K &> build_report/horse_10K.txt &
