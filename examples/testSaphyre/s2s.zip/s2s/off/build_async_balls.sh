cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building Balls in background...";
time ./escalunya_app -f Ball_Subd_3.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_3 &> build_report/Ball_Subd_3.txt &
time ./escalunya_app -f Ball_Subd_4.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_4 &> build_report/Ball_Subd_4.txt &
time ./escalunya_app -f Ball_Subd_5.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_5 &> build_report/Ball_Subd_5.txt &
time ./escalunya_app -f Ball_Subd_6.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_6 &> build_report/Ball_Subd_6.txt &
time ./escalunya_app -f Ball_Subd_7.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_7 &> build_report/Ball_Subd_7.txt &
time ./escalunya_app -f Ball_Subd_8.off --src_size=2 --sim_cell_size=1 --sim_fit_odt=0.15 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/Ball_Subd_8 &> build_report/Ball_Subd_8.txt &
