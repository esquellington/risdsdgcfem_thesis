cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_100K.off";
time ./escalunya_app -f armadillo_100K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_100K &> build_report/armadillo_100K.txt &
echo "...dragon_100K.off";
time ./escalunya_app -f dragon_100K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_100K &> build_report/dragon_100K.txt &
echo "...happy_100K.off";
time ./escalunya_app -f happy_100K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_100K &> build_report/happy_100K.txt &
echo "...horse_100K.off";
time ./escalunya_app -f horse_100K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/horse_100K &> build_report/horse_100K.txt &
