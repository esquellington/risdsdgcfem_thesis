cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_2K.off";
time ./escalunya_app -f armadillo_2K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_2K &> build_report/armadillo_2K.txt &
echo "...dragon_2K.off";
time ./escalunya_app -f dragon_2K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_2K &> build_report/dragon_2K.txt &
echo "...happy_2K.off";
time ./escalunya_app -f happy_2K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_2K &> build_report/happy_2K.txt &
echo "...horse_2K.off";
time ./escalunya_app -f horse_2K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/horse_2K &> build_report/horse_2K.txt &
