cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_1K.off";
time ./escalunya_app -f armadillo_1K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_1K &> build_report/armadillo_1K.txt &
echo "...dragon_1K.off";
time ./escalunya_app -f dragon_1K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_1K &> build_report/dragon_1K.txt &
echo "...happy_1K.off";
time ./escalunya_app -f happy_1K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_1K &> build_report/happy_1K.txt &
echo "...horse_1K.off";
time ./escalunya_app -f horse_1K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/horse_1K &> build_report/horse_1K.txt &
