cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building ALL in background...";
./build_async.sh;
./build_1K_async.sh;
./build_2K_async.sh;
./build_5K_async.sh;
./build_10K_async.sh;
./build_100K_async.sh;
./build_HD_async.sh;
