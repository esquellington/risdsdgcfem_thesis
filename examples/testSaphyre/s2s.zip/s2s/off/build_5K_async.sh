cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_5K.off";
time ./escalunya_app -f armadillo_5K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_5K &> build_report/armadillo_5K.txt &
echo "...dragon_5K.off";
time ./escalunya_app -f dragon_5K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_5K &> build_report/dragon_5K.txt &
echo "...happy_5K.off";
time ./escalunya_app -f happy_5K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_5K &> build_report/happy_5K.txt &
echo "...horse_5K.off";
time ./escalunya_app -f horse_5K.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/horse_5K &> build_report/horse_5K.txt &
