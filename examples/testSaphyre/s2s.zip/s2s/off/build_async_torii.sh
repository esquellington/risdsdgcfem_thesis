cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building Torii in background...";
time ./escalunya_app -f Torus_1K.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/Torus_1K &> build_report/Torus_1K.txt &
time ./escalunya_app -f Torus_4K.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/Torus_4K &> build_report/Torus_4K.txt &
time ./escalunya_app -f Torus_9K.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/Torus_9K &> build_report/Torus_9K.txt &
time ./escalunya_app -f Torus_16K.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/Torus_16K &> build_report/Torus_16K.txt &
time ./escalunya_app -f Torus_16K_Noise.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/Torus_16K_Noise &> build_report/Torus_16K_Noise.txt &
