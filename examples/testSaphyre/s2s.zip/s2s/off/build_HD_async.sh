cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "...armadillo_HD.off";
time ./escalunya_app -f armadillo_HD.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/armadillo_HD &> build_report/armadillo_HD.txt &
echo "...dragon_HD.off";
time ./escalunya_app -f dragon_HD.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/dragon_HD &> build_report/dragon_HD.txt &
echo "...happy_HD.off";
time ./escalunya_app -f happy_HD.off --src_size=1 --sim_cell_size=0.15 --sim_fit_odt=0.1 --sim_fit_lpc=0.1 --sim_fit_iter=20 -o ../sl/happy_HD &> build_report/happy_HD.txt &
