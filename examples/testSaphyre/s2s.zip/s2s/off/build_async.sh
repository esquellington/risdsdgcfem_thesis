cp /home/oscar/bzr/dev/pLa/bin/posix/c++11-release/escalunya_app .;
echo "building in background...";
echo "Parametric box3d";
time ./escalunya_app --src_size=0.9 --sim_cell_size=1 --sim_fit_odt=0 --sim_fit_iter=0 -o ../sl/box3d &> build_report/box3d.txt &
echo "...bunny.off";
time ./escalunya_app -f bunny.off --src_size=1 --sim_cell_size=0.2 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/bunny3d &> build_report/bunny.txt &
echo "...elephant.off";
time ./escalunya_app -f elephant.off --src_size=1 --sim_cell_size=0.1 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/elephant3d &> build_report/elephant.txt &
echo "...squirrel.off";
time ./escalunya_app -f squirrel.off --src_size=1 --sim_cell_size=0.1 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/squirrel3d > build_report/squirrel.txt &
echo "...armadillo.off";
time ./escalunya_app -f armadillo.off --src_size=1 --sim_cell_size=0.1 --sim_fit_odt=0.1 --sim_fit_iter=20 -o ../sl/armadillo3d &> build_report/armadillo.txt &
