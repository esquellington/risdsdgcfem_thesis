# Template
experiment_name = "experiments_Solid2D"
method = "scn_s2d"
params = []
params.append( ('name', [ "\"Solid\"" ] ) )
params.append( ('h', [ "[2.1,0.6]" ] ) )
params.append( ('nx', [ "25" ] ) )
params.append( ('ny', [ "13" ] ) )
params.append( ('dt', [ "0.033" ] ) )
params.append( ('thickness', [ "0.01" ] ) )
params.append( ('density', [ "100" ] ) )
params.append( ('young_modulus', [ "1000" ] ) )
params.append( ('poisson_ratio', [ "0.25" ] ) )
params.append( ('damping_ratio', [ "0" ] ) )
params.append( ('%vec_kpc', [ "[ -2.1 -0.6 ]" ] ) )
params.append( ('%gravity', [ "[0 -100.0]" ] ) )
params.append( ('%mm', [ "\"C_WRP\"", "\"C_LCM\"", "\"C_LCMH\"" ] ) )
params.append( ('%rm', [ "\"MSVD\"" ] ) ) #params.append( ('%rm', [ "\"MSVD\"", "\"DAPD\"" ] ) )
params.append( ('%dm', [ "\"T\"" ] ) ) #params.append( ('%dm', [ "\"T\"", "\"I\"" ] ) )
params.append( ('%integrator', [ "\"FIE dx\"" ] ) ) #params.append( ('%integrator', [ "\"QIE v\"", "\"FIE dx\"" ] ) )
params.append( ('%nr_iter', [ "1", "2", "3" ] ) ) #params.append( ('%nr_iter', [ "1", "2", "3", "4", "5" ] ) )
params.append( ('%nr_rel_epsilon', [ "0.01", "0.001" ] ) )
params.append( ('%ls_solver', [ "\"CG\"" ] ) ) #params.append( ('%ls_solver', [ "\"CG\"", "\"GMRES\"" ] ) )
params.append( ('%ls_iter', [ "50" ] ) ) #params.append( ('%ls_iter', [ "10", "20" ] ) )
params.append( ('%ls_restarts', [ "50" ] ) )
params.append( ('%ls_rel_epsilon', [ "0.05", "0.01", "0.001" ] ) )

# Build array of explicit commands from template
# command = method + ( + params[i][j] + )
# for each sequential parameter expand all existing partial commands with all its potential values params[i][j] (commands = commands x param[i])
commands = [ method + "(" ]
var_commands = [ "" ]
for it_param in params:
    param_name, param_range = it_param
    # expand full commands
    tmp_commands = []
    for it_command in commands:
        for it_value in param_range:
            tmp_commands.append( it_command + " " + param_name + " = " + it_value + "," )
    commands = tmp_commands
    # expand var params, ignoring fixed params
    tmp_var_commands = []
    for it_vc in var_commands:
        if len(param_range) > 1:
            for it_value in param_range:
                tmp_var_commands.append( it_vc + " " + param_name + " = " + it_value + "," )
        else:
            for it_value in param_range:
                tmp_var_commands.append( it_vc )
    var_commands = tmp_var_commands
#print var_commands
#print commands

# Build final skr commands to be run, with ordinal output file names
skr_scripts = []
num_commands = 0
for it_command in commands:
    file_sufix = "_stats_" + str(num_commands) + ".txt"
    skr_scripts.append( it_command + " ); "
                        + "stats_monitor( name = \"Solid\"" + ", file_sufix = \"" + file_sufix + "\" ); "
                        + "scn_step( t=5, dt=0.033 ); "
                        + "_abort(); " ) #abort required to exit from console-mode test_Saphyre
    num_commands += 1

# Run commands and store results in experiment dir
#TODO: Run each sim in several processes/threads to reduce comp time
#TODO: Could implement some sort of hashed-cache scheme to avoid repeating experiments when adding/removing param values?
import subprocess
import math
print "Running", num_commands, "experiments..."
executable_name = "~/bzr/dev/pLa/bin/posix/ultimate/test_Saphyre"
subprocess.call("mkdir " + experiment_name, shell=True)
num_commands = 0
for it_skr in skr_scripts:
    #print "Running:", it_skr
    print "experiment", num_commands, "..."
    # Setup temporary .skr script
    skr_file_name = experiment_name + "/tmp.skr"
    f = open( skr_file_name,'w');
    f.write( it_skr )
    f.close()
    # Execute commands .skr
    output_file_name = "Solid_stats_" + str(num_commands) + ".txt"
    subprocess.call( executable_name + " -c -f " + skr_file_name, shell=True );
    # Add explicit command as comment on output file
    f = open( output_file_name, 'a' ); f.write( "#---- Command ----\n# " + it_skr )
    # Move output file to experiment dir
    subprocess.call( "mv " + output_file_name + " " + experiment_name + "/", shell=True );
    num_commands += 1
print "...Done!"

# Create gnuplot commands file
#TODO: Do if parametrically, allowing user to specify a magnitude name to be plot and computing its column index automatically
#TODO: Print fixed param values as global title
#DONE: Print var param values for each plot
#DONE: Force same x,y scale for all plots
print "Creating gnuplot script..."
fixed_params = "fixed:"
var_params = "var:"
all_params = method + "("
for it_param in params:
    param_name, param_range = it_param
    if len(param_range) > 1:
        all_params = all_params + " " + param_name + " = < "
        var_params = var_params + " " + param_name + " = < "
        for it_value in param_range:
            all_params = all_params + it_value + ", "
            var_params = var_params + it_value + ", "
        all_params = all_params + ">, "
        var_params = var_params + "> "
    else:
        all_params = all_params + " " + param_name + " = " + param_range[0] + ", "
        fixed_params = fixed_params + " " + param_name + " = " + param_range[0] + ", "
all_params = all_params + ")"

layout_rows = math.ceil( math.sqrt(num_commands) )
gnuplot_file_name = experiment_name + "/" + experiment_name + ".gnuplot"
gnuplot_file = open( gnuplot_file_name, "w" )
gnuplot_file.write( "#Plots with fixed params: " + fixed_params + "\n")
gnuplot_file.write( "#First, plot all curves together to a null terminal in order to compute the global yrange...\n" );
gnuplot_file.write( "set terminal unknown\n" )
num_commands = 0
for it_command in commands:
    output_file_name = "Solid_stats_" + str(num_commands) + ".txt"
    if num_commands == 0:
        gnuplot_file.write( "plot '" + output_file_name + "' using 1:25\n" )
    else:
        gnuplot_file.write( "replot '" + output_file_name + "' using 1:25\n" )
    num_commands += 1
gnuplot_file.write( "#...then, multiplot to an image setting the global yrange explicitly\n" );
gnuplot_file.write( "set terminal pngcairo enhanced font \"ubuntu,10\" size 4000,2000\n" )
gnuplot_file.write( "set output 'Multiplot-1:25.png'\n" )
gnuplot_file.write( "reset\n" )
gnuplot_file.write( "set style function lines\n" )
gnuplot_file.write( "set multiplot layout " + str(layout_rows) + "," + str(math.ceil(num_commands/layout_rows)) + " title '" + all_params + "'\n" )
gnuplot_file.write( "set xrange [0:5]\n" ) #\todo xrange explicit, by now...
gnuplot_file.write( "set yrange [ GPVAL_Y_MIN : GPVAL_Y_MAX ]\n" ) #Set yrange to previously computed global yrange
num_commands = 0
for it_command in commands:
    output_file_name = "Solid_stats_" + str(num_commands) + ".txt"
    gnuplot_file.write( "set title '" + var_commands[num_commands] + "'\n" )
    gnuplot_file.write( "plot '" + output_file_name + "' using 1:25 with lines title ''\n" )
    num_commands += 1
gnuplot_file.write( "unset multiplot\n" )
gnuplot_file.close();
print "...Done!"
